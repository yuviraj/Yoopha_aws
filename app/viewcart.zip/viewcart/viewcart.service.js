/* jshint browser: true */
/* jshint devel: true */
/* jshint latedef:nofunc */

(function(angular) {
    'use strict';

    /**
    * @ngdoc service
    * @name 'Uploading service'
    * @description
    * Service in the yoophaWeb.
    */
    angular.module('yoophawebapp')
        .service('viewCartService', viewCartService);

    /** @ngInject */
    function viewCartService($q, $localStorage, getData, postData, utilities) {

        var service = {};
        var url = '';

        service.cart = undefined;
        service.userData = undefined;
        service.masterCart = undefined;
        service.isMasterCartExist = undefined;
        service.getUserData = getUserData;
        service.getCartData = getCartData;
        service.createMasterCart = createMasterCart;
        service.getMasterCart = getMasterCart;
        service.delCartItems = delCartItems;
        service.updateCartItem = updateCartItem;
        return service;

        function getUserData(id) {
            url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/common/users/' + id;
            return returnData('userData');
        }

        function getCartData(id){
            url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/cart/' + id;
            return returnData('cart');
        }

        function getMasterCart(id){
            url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/master_cart_details/' + id;
            return returnData('isMasterCartExist');   
        }

        function createMasterCart(data){
            url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/create_master_cart/';
            var deferred = $q.defer();
            postData.async(url, data)
                .then(function(res) {
                if(res.status == 201 && res.statusText == 'Created')
                    deferred.resolve(res.data);
                else 
                    deferred.reject(res.data);
                });
            return deferred.promise;
        }

        function delCartItems(id, cart_type){
            if(cart_type == 1)
                url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/' + id + '/delete_cartitem/';
            else
                url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/' + id + '/delete_otccartitem/';
            var deferred = $q.defer();
            postData.del(url)
                .then(function (res) {
                    if(res.status == 204){
                        deferred.resolve('success');
                    } else {
                        deferred.reject('error');
                    }
                });
            return deferred.promise;
        }

        function updateCartItem(id, data, cart_type) {
            var deferred = $q.defer();
            if(cart_type == 1)
                url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/' + id + '/cartitemsupdate/';
            else 
                url = 'http://ec2-35-154-138-58.ap-south-1.compute.amazonaws.com/api/v1/cart/' + id + '/otccartitemsupdate/';
            postData.put(url, data)
                .then(function (res){
                    deferred.resolve(res);
                }, function (err){
                    deferred.reject(err);
                })
            return deferred.promise;
        }

        function returnData(data) {
            var deferred = $q.defer();

            if (!service[data])  {
                getData.asyncHead(url).then(function (response) {
                if (response.length > 0) {
                    service[data] = response.data.results;
                    deferred.resolve(response);
                } else if (angular.isObject(response)) {
                    service[data] = response.data.results;
                    deferred.resolve(response);
                  } else {
                    deferred.reject(response);
                }
                });
          } else {
            deferred.resolve(service[data]);
          }

          return deferred.promise;
        }
    }
})(angular);