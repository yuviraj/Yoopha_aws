(function(angular) {
  'use strict';

  angular
  .module('yoophawebapp')
  .controller('ViewCartController', ViewCartController);

    function ViewCartController($scope, $state, $localStorage, viewCartService, homeService) {
        var vm = this;
        var incomplete_cart = [];
        var userinfo;

        vm.viewData = {};
        vm.mastercartIfExist = undefined;
        vm.createMasterCart = createMasterCart;
        vm.getMasterCart = getMasterCart;
        vm.deleteCart = deleteCart;
        vm.updateQty = updateQty;

        init();

        function init() {
        	userinfo = $localStorage['usr'];
            homeService.getExistingOtcCart(userinfo.usr_id)
                .then(function (res) {
                    $localStorage['incomp_cart'][1] = homeService.existingOtcCartInfo.results[0];
                    incomplete_cart = $localStorage['incomp_cart'];
                    getCart();
                    getMasterCart();
            });

        }

        function getMasterCart() {
            viewCartService.getMasterCart(userinfo.usr_id)
                .then(function (res){
                    if(viewCartService.isMasterCartExist[0] != null){
                        vm.mastercartIfExist = viewCartService.isMasterCartExist[0];
                        $localStorage['masterCart'] = viewCartService.isMasterCartExist[0];
                    }
                    else{
                        vm.mastercartIfExist = undefined;
                        delete $localStorage['masterCart'];
                    }
                });
        }

        function getuser(){
        	viewCartService.getUserData(userinfo.usr_id)
        		.then(function (res){
        			userinfo.username = viewCartService.userData.username;
        			userinfo.email = viewCartService.userData.email;
        			userinfo.mobile_no = viewCartService.userData.mobile_no;
        			$localStorage['usr'] = userinfo;
        		})
        }

        function getCart() {
            if(angular.isDefined(incomplete_cart)){
                vm.viewData.p_cart = incomplete_cart[0];
                vm.viewData.o_cart = incomplete_cart[1];
            }
        }

        function createMasterCart() {
        	if(angular.isUndefined($localStorage['masterCart'])){
        		var data = {
        			'otccart': vm.viewData.o_cart.id,
        			'user': userinfo.usr_id,
        			'prescart': vm.viewData.p_cart.id
        		};
        		viewCartService.createMasterCart(data)
        			.then(function (res){
        				$localStorage['masterCart'] = res;
        				$state.go('Cart');
        			}, function (err){
        				alert(err);
        			})
        	} else {
        		$state.go('Cart');
        	}
        }

        function hasID(list, item){
            if(list.length != 0){
                for(var i = 0; i < list.length; i++){
                    if(list[i].id == item.id)
                        return i;
                }
                return -1;
            } else {
                return -1;
            }
        }

        function deleteCart(item, index_id){
            var index = hasID(index_id == 1 ? vm.viewData.p_cart.cartitems : vm.viewData.o_cart.otccartitems, item);
            viewCartService.delCartItems(item.id, index_id)
                .then(function (res) {
                    if(index_id == 1){
                        if(index != -1){
                            vm.viewData.p_cart.cartitems.splice(index, 1);
                            $localStorage['incomp_cart'][0].cartitems = vm.viewData.p_cart.cartitems;
                        }
                    }else {
                        if(index != -1){
                            vm.viewData.o_cart.otccartitems.splice(index, 1);
                            $localStorage['incomp_cart'][1].otccartitems = vm.viewData.o_cart.otccartitems;
                        }
                    }
                }, function (err){

                })
        }

        function updateQty(item, action, cart_type) {
            if(action){
                item.quantity++;
            }else {
                if(item.quantity <= 1){
                    del_selected_drug(item);
                }else {
                    item.quantity--;
                }
            }
            item.price = updatePrice(item) * item.quantity;
            // var temp = {};
            // angular.copy(item, temp);
            // if(cart_type == 1){
            //     var temp_id = temp.product.id;
            //     temp.product = temp_id;
            //     viewCartService.updateCartItem(temp.id, temp, cart_type)
            //         .then(function (res){
            //             var index = hasID(vm.viewData.p_cart.cartitems, item);
            //             $localStorage['incomp_cart'][0].cartitems[index] = item; 
            //         }, function (err) {
            //            item.quantity =  action ? (item.quantity <= 1 ? item.quantity : item.quantity--) : item.quantity ++;
            //         })
            // }else {
            //     var temp_id = temp.otcproduct.id;
            //     temp.otcproduct = temp_id;
            //     viewCartService.updateCartItem(temp.id, temp, cart_type)
            //         .then(function (res){
            //             var index = hasID(vm.viewData.o_cart.otccartitems, item);
            //             $localStorage['incomp_cart'][1].otccartitems[index] = item; 
            //         }, function (err) {
            //            item.quantity =  action ? (item.quantity <= 1 ? item.quantity : item.quantity--) : item.quantity ++;
            //         })
            // }
        }

        function updatePrice(item) {
            console.log(parseInt(item.price) / item.quantity);
            return  (parseInt(item.price) / item.quantity);
        }

    }
})(angular);
